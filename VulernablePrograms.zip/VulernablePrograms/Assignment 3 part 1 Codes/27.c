#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int authCheck(char *password)
{
	char buffer[20];
	int authFlag = 0;

	strcpy(buffer,password);
	if(strcmp(buffer,"pass_cust1")==0)
		authFlag = 1;
	if(strcmp(buffer,"pass_cust2")==0)
		authFlag = 1;
	return authFlag;
}

int main(int argc, char *argv[])
{
	if(argc<2)
	{
		printf("Enter in this format: %s <password>\n",argv[0]);
		exit(0);
	}
	if(authCheck(argv[1]))
	{
		printf("\nAccess granted\n");
	}
	else
	{
		printf("\nAccess denied\n");
		exit(0);
	}

	int i;
	int userChoice;
	float digibal = 50.0;
	float bankbal = 100.0;
	float amount = 0.0;

	do
	{
		printf("\nWelcome to DigiPay! Pay the digital way!\n");
		printf("\nSelect operation");
		printf("\n1. View wallet balance");
		printf("\n2. Add money to wallet");
		printf("\n3. Make payment");
		printf("\n4. Quit");

		scanf("%d",&userChoice);

		switch(userChoice)
		{
			case 1:
				printf("\nDigi wallet balance: %f\n",digibal);
				break;
			case 2:
				printf("\nEnter amount:");
				scanf("%f",&amount);
				if(amount<=bankbal)
				{
					if(amount<=100 && amount>=10)
					{
						digibal+=amount;
						bankbal-=amount;
						printf("%f added to Digi Wallet\n",amount);
						printf("Digi wallet balance: %f\n",digibal);
					}
					else
						printf("\nEnter amount within range: $10 to $100\n");
				}
				else
					printf("\nInsufficient balance in bank account\n");
				break;
			case 3:
				printf("\nEnter amount to be paid:");
				scanf("%f",&amount);
				if(amount<=digibal)
				{
					digibal-=amount;
					printf("\nPayment successful!\n");
					printf("Digi wallet balance: %f\n",digibal);
				}
				else
					printf("\nInsufficient balance in Digi wallet! Add money to wallet\n");
				break;

			case 4:
				printf("\nThank you for using DigiPay!\n");
				break;
		}
	}while(userChoice!=4);

	return 0;
}