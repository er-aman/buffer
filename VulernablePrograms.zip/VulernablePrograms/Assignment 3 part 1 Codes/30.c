#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int check_authentication(char *password){
	int auth_flag=0;
	char password_buffer[16];


	strcpy(password_buffer,password);


if(strcmp(password_buffer,"oscar")==0)
auth_flag=1;
if(strcmp(password_buffer,"bruno")==0)
auth_flag=1;

return auth_flag;

}

int main(int argc,char *argv[]){

if(argc<2){
	printf("Usage: %s <password>\n",argv[0]);
	exit(0);
}
if(check_authentication(argv[1])){
	printf("\n======================\n");
	printf("  Access Granted.\n");
	printf("\n======================\n");

}else{
	printf("\nAccess Denied.\n");
	exit(0);
}

char name[100],moviename[100];
int days,type;
int rentalrate;

do{



	printf("please enter you name\n");
	scanf("%s",name);

    printf("enter the name of the moviee\n");
    scanf("%s",moviename);

    printf("enter the number of days you want to rent the moviee\n");
    scanf("%d",&days);

	printf("Enter the type of moviee you would like to watch\n");
	printf("'1' for regular movie\n");
	printf("'2' for new movie\n");
	printf("'3' for kids movie\n");
    scanf("%d",&type);

    switch(type){
    	case 1:
    	   rentalrate=40*days;
    	   printf("your rental rate:");
    	   printf("%d\n",rentalrate);
    	   break;

    	   case 2:
    	   rentalrate=60*days;
           printf("your rental rate:");
    	   printf("%d\n",rentalrate);
    	   break;
    	   


    	   case 3:
    	   rentalrate=45*days;
    	   printf("your rental rate:");
    	   printf("%d\n",rentalrate);
    	   break; 
           

    	   case 4:printf("----thank you------");
    	   break;

    }

}while(type !=4);
return 0;

}
