#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct atm_use{
	int acc;
	int pin;
	long bal;
	char name[20];
};

void true()
{
	int ch;
	printf("\nOption 1: User\n");
	printf("Option 2: Admin\n");
	printf("Option 3: Exit\n");
	printf("Choose option:");
	scanf("%d",&ch);
	printf("\n");
	switch(ch)
	{
		case 1:
			user();
			break;
		case 2:
			admin();
			break;
		case 3:
			exit(0);
		default:
			true();
	}	
}

int conf_pin(char *str)
{
	int temp=0;
	char buff[9];
	strcpy(buff,str);
	int b = strcmp(buff,"1234");
	if(b != 0)
		printf("\nWrong Pin Entered\n");
	else
		temp=1;

	return temp;
}

void admin()
{
	int ch1;
	printf("\nOption 1: Add Acc\n");
	printf("Option 2: Delete Acc\n");
	printf("Option 3: See all Acc\n");
	printf("Option 4: Return to Main\n");
	printf("Choose option:");
	scanf("%d",&ch1);
	printf("\n");
	switch(ch1)
	{
		case 1:
			printf("User Added");
			true();
			break;
		case 2:
			printf("User Deleted");
			true();
			break;
		case 3:
			printf("Displaying all Acc");
			true();
			break;
		case 4:
			true();
		default:
			true();
	}
}

void user()
{
	int ch1;
	printf("\nOption 1: Check Balance\n");
	printf("Option 2: Withdraw\n");
	printf("Option 3: Deposite\n");
	printf("Option 4: Return to Main\n");
	printf("Choose option:");
	scanf("%d",&ch1);
	printf("\n");
	switch(ch1)
	{
		case 1:
			printf("Acc No");
			printf("Balance");
			true();
			break;
		case 2:
			printf("Acc No");
			printf("Withdraw");
			true();
			break;
		case 3:
			printf("Acc No");
			printf("Deposite");
			true();
			break;
		case 4:
			true();
		default:
			true();
	}
}

int main(int argc, char  *argv[])
{
	/* code */
	printf("***************************");
	printf("\nWelcome to XYZ Bank ATM\n");
	printf("***************************");
	printf("\nInsert your Card and enter Pin Number for verification\n");
	char as[9];
	gets(as);
	if(conf_pin(as))
		true();
}
