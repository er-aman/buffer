#include <iostream>   
#include <cstdlib>    
#include <cmath>      
#include <stdio.h>
#include <string.h>

void main_menu();

int main()
{
    char userName[15];
    char password[10];
    char loginSuccess=0;

    printf("Enter your username\n");
    gets(userName);

    printf("Enter your password\n");
    gets(password);

    if(strcmp(password, "4321") == 0) {
        loginSuccess = '1';
    } else {
        printf("Wrong Password\n");
    } 

    if (loginSuccess) {
        main_menu();
    }

    return 0;
}


void main_menu(){      
  int option;
  int totalAmount = 500;
  int amount;      
  printf("Please select a number\nfor your desired action\n[1]  Withdrawal\n[2]  Deposit\n[3]  Quit\n");
  scanf("%d", &option);
  
  switch (option)
  {
      case 1:
          printf("Your current amount is %d \n", totalAmount);  
          printf("Enter amount to be withdrawn\n");
          scanf("%d", &amount);
          totalAmount = totalAmount - amount;
          printf("Your current amount after transcation is %d \n", totalAmount);
          exit(0);
          break;
      
      case 2:
          printf("Your current amount is %d \n", totalAmount);  
          printf("Enter amount to be deposited\n");
          scanf("%d", &amount);
          totalAmount = totalAmount + amount;
          printf("Your final amount after transcation is %d \n", totalAmount);
          exit(0);
          break;
      
      case 3:
          printf("Your current amount is %d\n Thank you for banking \n", totalAmount);  
          exit(0);

      default:
            printf("Please enter the desire input\n");
            main_menu();
          break;
  }
}