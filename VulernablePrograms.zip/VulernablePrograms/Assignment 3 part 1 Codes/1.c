#include<stdio.h>
#include<string.h>
struct employee {
	char firstname[10];
	char lastname[10];
	char id[10];
};
struct employee emp[10];
void loadDetails()
{
	struct employee e1 = {"Sonam", "Kapoor", "uta1"};
	struct employee e2 = {"Johnny", "Yesss papa", "uta2"};
	struct employee e3 = {"Shahid", "Kapoor", "uta3"};
	struct employee e4 = {"Arjun", "Kapoor", "uta4"};

	emp[0] = e1;
	emp[1] = e2;
	emp[2] = e3;
	emp[3] = e4;


}

void passtest(char p[5])
{
	int i;
	loadDetails();
	struct employee e5 = {"Karen", "Love", "uta5"};
	emp[1] = e5;
	for(i=0;i<4;i++){
		printf("Name: %s\n", emp[i].firstname);
		printf("Lastname: %s\n", emp[i].lastname);
		printf("id: %s\n", emp[i].id);
	}
}

void failtest()
{
	int i;
	loadDetails();
	printf("You have failed the test ");
}

main(){
	char key[4] = "aaa";
	   char valid=0;
	char pass_key[15];
	
	printf("Enter the pass key");
	gets(pass_key);
	if(strcmp(key, pass_key)==0)
	{
  valid=1;
	}  
	    if(valid){     printf("Processing your request \n");
                 passtest(pass_key);
	    }else{
	   failtest(); 	
	    } 
}