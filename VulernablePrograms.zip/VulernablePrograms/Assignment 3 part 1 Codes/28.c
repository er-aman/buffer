#include <stdio.h>
#include <stdlib.h>

//this functions checks for input validation of the subject code
//accepted subject code DB1, CN1, SE1, DS, CC, ALG, ST, WDM, SP

void check_subject_input(char* subject)
{
   if(strcmp(subject,"DB1") == 0 || strcmp(subject,"CN1") == 0 || strcmp(subject,"SE1") == 0 || strcmp(subject,"DS") == 0 || strcmp(subject,"CC") == 0 || strcmp(subject,"ALG") == 0 || strcmp(subject,"ST") == 0 || strcmp(subject,"WDM") == 0 || strcmp(subject,"SP") == 0)
   {
      return;
   }
   printf("Invalid Subject code entered........ Exiting application!!\n");
   exit(1);
}

//this function checks for the input validation of the grades
//accepted values for grade A, B, C, D, I

void check_grade_input(char grade)
{
   if(grade == 'A' || grade == 'B' || grade == 'C' || grade == 'D' || grade == 'I')
   {
      return;
   }
   printf("Invalid grade entered......... Exiting the application!!\n");
   exit(1);
}

//this function converts the grade to the point

int get_grade_point(char grade)
{
   switch(grade)
   {
      case 'A':
         return(4.0);
      case 'B':
         return(3.0);
      case 'C':
         return(2.0);
      case 'D':
         return(1.0);
      case 'I':
         return(0.0);
   }
}

int application()
{
   char filename[12] = "student.txt";
   FILE *fp = fopen(filename,"a");
   char output[43] = "\n";
   char name[20];
   char subject[3];
   char grade[2];
   char temp[5];
   int i;
   int j;
   float gpa = 0;
   
   if(fp == NULL)
   {
      printf("Error in opening the file....... Exiting the application!!\n");
      fclose(fp);
      return(1);
   }

   printf("Enter the Name of the Student: ");
   fgets(name, 20, stdin);
   if(strlen(name) < 20)
   {
      name[strlen(name)-1] = '\0';
   }
   name[0] = toupper(name[0]);
   strcat(output, name);
   strcat(output, " ");

   //3 subjects are assumed for each student
   for(j=0 ; j<3 ; j++)
   {
      subject[0] = '\0';
      printf("Enter the Subject Code: ");
      fgets(subject, 5, stdin);
      subject[strlen(subject)-1] = '\0';
      for(i=0 ; i<strlen(subject) ; i++)
      {
         subject[i] = toupper(subject[i]);
      }
      check_subject_input(subject);
      strcat(output, subject);
      strcat(output, " ");
   
      printf("Enter the Final Grade: ");
      fgets(grade, 3, stdin);
      grade[0] = toupper(grade[0]);
      check_grade_input(grade[0]);
      grade[1] = '\0';
      strcat(output, grade);
      strcat(output, " ");
      gpa += get_grade_point(grade[0]);
   }
   gpa = gpa / 3;
   snprintf(temp,5,"%f",gpa);
   strcat(output,temp);
   output[strlen(output)-1] = '\0';

   //the final grades are written to the file
   fputs(output,fp);

   fclose(fp);
}

int check_username(char *str)
{
   int ret_val = 0;
   char username_buffer[16];
   strcpy(username_buffer,str);
   if(strcmp(username_buffer,"adminadmin") == 0)
      ret_val = 1;
   else if(strcmp(username_buffer,"admin") == 0)
      ret_val = 1;
   return(ret_val);
}

int check_password(char *str)
{
   int ret_val = 0;
   char password_buffer[16];
   strcpy(password_buffer,str);
   if(strcmp(password_buffer,"adminadmin") == 0)
      ret_val = 1;
   else if(strcmp(password_buffer,"admin") == 0)
      ret_val = 1;
   return(ret_val);
}

int main(int argc, char *argv[])
{
   if(argc != 3)
   {
      printf("Invalid no of arguments provided.. Exiting the application!!\n");
      exit(0);
   }
   if(check_username(argv[1]) && check_password(argv[2]))
   {
      printf("Access Granted Successfully !!\n");
      printf("\n Welcome to UTA Gradebook for Department Computer Science!!\n\n");
      application();
   }
   else
   {
      printf("Access denied..... Invalid username/password..... Exiting the application!!\n");
      exit(1);
   }
   return(0);
}
