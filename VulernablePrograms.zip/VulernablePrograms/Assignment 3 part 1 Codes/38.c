/* ##################Movie Rental################# */

#include <stdio.h>
#include <assert.h>
#include <ctype.h>
#include <locale.h>
#include <math.h>
#include <setjmp.h>
#include <signal.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int not_verifying(char userI1[16],char userI2[16])
{
    int real=1;
    char username[16];
    char password[16];

    strcpy(username,userI1);
    strcpy(password,userI2);

    if(strcmp(username,"Sumedh")!=0)
    {
        if(strcmp(password,"qwerty123")!=0)
        {
            real=0;
        }
    }
    return real;
}

double buy(char Name[16])
{
    double Price;
    char name[16];
    strcpy(name,Name);
    if(strcmp(name,"Gone_Girl")==0)
    {
        Price=5;
    }
    else if(strcmp(name,"Dracula_Untold")==0)
    {
        Price=7;
    }
    else if(strcmp(name,"Mad_Max-Fury_Road")==0)
    {
        Price=9;
    }
    else if(strcmp(name,"Last_Vegas")==0)
    {
        Price=8;
    }
    else if(strcmp(name,"ShawShank_Redemption")==0)
    {
        Price=100;
    }
    else if(strcmp(name,"Godfather")==0)
    {
        Price=100;
    }
    else
    {
        Price=0;
        printf("Improper Item");
    }
    return Price;
}

double rent(int week,char Name[16])
{
    double Price;
    char name[16];
    strcpy(name,Name);
    if(strcmp(name,"Gone_Girl")==0)
    {
        Price=week * 2;
    }
    else if(strcmp(name,"Dracula_Untold")==0)
    {
        Price=week * 2.25;
    }
    else if(strcmp(name,"Mad_Max-Fury_Road")==0)
    {
        Price=week*3;
    }
    else if(strcmp(name,"Last_Vegas")==0)
    {
        Price=week*2.6;
    }
    else if(strcmp(name,"ShawShank_Redemption")==0)
    {
        Price=week*10;
    }
    else if(strcmp(name,"Godfather")==0)
    {
        Price=week*10;
    }
    else
    {
        Price=0;
        printf("Improper_Item");
    }
    return Price;
}

double sell(char Name[16])
{
    double Price;
    char name[16];
    strcpy(name,Name);
    if(strcmp(name,"Gone_Girl")==0)
    {
        Price=-3;
    }
    else if(strcmp(name,"Dracula_Untold")==0)
    {
        Price=-5;
    }
    else if(strcmp(name,"Mad_Max-Fury_Road")==0)
    {
        Price=-6;
    }
    else if(strcmp(name,"Last_Vegas")==0)
    {
        Price=-5.5;
    }
    else if(strcmp(name,"ShawShank_Redemption")==0)
    {
        Price=-60;
    }
    else if(strcmp(name,"Godfather")==0)
    {
        Price=-60;
    }
    else
    {
        Price=0;
        printf("Improper Item");
    }
    return Price;
}

void main()
{
    char userI1[16];
    char userI2[16];
    int choice;
    int choice1;
    char choice2[16];
    double choice3;
    int choice4;
    int end=0;
    double price=0;
    printf("\t\t\t\t\t\tMovie Rental Portal");
    printf("\n##################################################################");
    printf("\n\t\t\t\tHello Welcome to NEW MOVIE RENTALS.");
    printf("\n##################################################################");
    printf("\n\tPlease Enter the following Credentials\n\n");
    printf("USERNAME: ");
    scanf("%s",&userI1);
    printf("\nPASSWORD: ");
    scanf("%s",&userI2);
    choice=not_verifying(userI1,userI2);
    if(choice==1)
    {
        printf("\n\n\n\t\t WELCOME \n\t\t\t%s",userI1);
        printf("\n\tYOU HAVE BEEN LOGGED IN SUCESSFULLY!!");
        while(end==0)
        {
            printf("\n\tENTER ONE OF YOUR FOLLOWING PREFERENCES:");
            printf("\n\t Enter\n\t1 for Buying a Movie.\n\t2 for Renting a movie\n\t3 for Selling a pre-owned movie Cd:");
            scanf("%d",&choice1);
            if(choice1==1)
            {
                printf("\n\n\n\n\n\n\n\n");
                printf("##################################################################");
                printf("\n\t\t\t\tBUYING MOVIES");
                printf("\n##################################################################");
                //printf("\n\n");
                printf("\nFollowing is the list of movies and their corresponding prices");
                printf("Enter the name of the movie as mentioned above(case sensitive), to buy it.");
                printf("\n\n");
                printf("\t NAME:Gone_Girl\t\tPRICE:$5.00\n");
                printf("\t NAME:Dracula_Untold\tPRICE:$7.00\n");
                printf("\t NAME:Mad_Max-Fury_Road\tPRICE:$9.00\n");
                printf("\t NAME:Last_Vegas\t\tPRICE:$8.00\n");
			printf("\t NAME:ShawShank_Redemption\tPRICE:$100.00\n");
                printf("\t NAME:Godfather\tPRICE:$100.00\n");
                printf("\n\n\tCHOICE:");
                scanf("%s",&choice2);
                printf("\nYou are trying to buy %s\n",choice2);
                choice3=buy(choice2);



            }
            else if (choice1==2)
            {
                printf("\n\n\n\n\n\n\n\n");
                printf("##################################################################");
                printf("\n\t\t\t\tRENTING MOVIES");
                printf("\n##################################################################");
                printf("\n\n");
                printf("\nFollowing is the list of movies and their corresponding prices");
                printf("Enter the name of the movie as mentioned above(case sensitive), to rent it.");
                printf("\n\n");
                printf("\t NAME:Gone_Girl\tPRICE:$2.00 per week\n");
                printf("\t NAME:Dracula_Untold\tPRICE:$2.25 per week\n");
                printf("\t NAME:Mad_Max-Fury_Road\tPRICE:$3.00 per week\n");
                printf("\t NAME:Last_Vegas\tPRICE:$2.60 per week\n");
			    printf("\t NAME:ShawShank_Redemption\tPRICE:$10.00 per week\n");
                printf("\t NAME:Godfather\tPRICE:$10.00 per week\n");
                printf("\n\n\tCHOICE:");
                scanf("%s",&choice2);
                printf("\n\t ENTER THE NUMBER OF WEEKS YOU WANT TO RENT IT FOR");
                scanf("%d",&choice4);
                printf("\nYou are trying to rent %s\n",choice2);
                choice3=rent(choice4,choice2);
            }
            else if (choice1==3)
            {
                printf("\n\n\n\n\n\n\n\n");
                printf("##################################################################");
                printf("\n\t\t\t\tSELLING MOVIES");
                printf("\n##################################################################");
                //printf("\n\n");
                printf("\nFollowing is the list of movies and their corresponding prices");
                printf("Enter the name of the movie as mentioned above(case sensitive), to sell it.");
                printf("\n\n");
                printf("\t NAME:Gone_Girl\tPRICE:$3.00\n");
                printf("\t NAME:Dracula_Untold\tPRICE:$5.00\n");
                printf("\t NAME:Mad_Max-Fury_Road\tPRICE:$6.00\n");
                printf("\t NAME:Last_Vegas\tPRICE:$5.5.00\n");
			    printf("\t NAME:ShawShank_Redemption\tPRICE:$60.00\n");
                printf("\t NAME:Godfather\tPRICE:$60.00\n");
                printf("\n\n\tCHOICE:");
                scanf("%s",&choice2);
                printf("\nYou are trying to sell %s\n",choice2);
                choice3=sell(choice2);
            }
            else
            {
                printf("PLEASE ENTER THE RIGHT CHOICE");
            }
            printf("\tDo you want to continue shopping?\n\tEnter 0 for yes and 1 for no");
            scanf("%d",&end);
            price=price+choice3;
            printf("\n##################################################################");
            printf("\n\t\t\tPAYABLE AMOUNT = $%f",price);
            printf("\n##################################################################");

        }
        printf("\n\t\t\tTHANKYOU FOR SHOOPING WITH US.");
    }
}
