#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int verifyUser(char *userInput);
void viewGrades();
void welcomeMenu();
void addStudent();

int main() {
	int giveAccess=0;
	char username[14]; //username can 12 chars max
	char password[14]; //password 12 chars max
	
	//ask user for login credentials
	printf("Login to Gradebook\n");
	printf("Username: ");
	if(fgets(username,14,stdin)) //get username from user (get only 12 chars)
	{
		username[strlen(username)-1]='\0'; //null terminate string (eliminate trailing new line)
		//proceed only if entered username is non-empty
		if(strlen(username)!=0)
		{
			setbuf(stdin,NULL); //flush out excess user input from stdin
			printf("Password: ");
			scanf("%s",&password); //get password from user
			getchar(); //capture new line
			
			if(strlen(password)!=0)
			{
				char combo[28]={0}; //initialize buffer with null-terminators
				//combo stores user input as "username,password" to compare with credentials.txt file content
				strncat(combo,username,sizeof(combo)-1);
				strncat(combo,",",sizeof(combo)-strlen(username)-1);
				strncat(combo,password,sizeof(combo)-strlen(username)-1-1);
				
				int giveAccess = verifyUser(combo); //validate user entered credentials
				
				char passwordHint[50]={0}; //pre-null-terminated buffer for password feedback text (in case of incorrect credentials)
				strncpy(passwordHint, "The password entered '",sizeof(passwordHint)-1);
				strncat(passwordHint,password,sizeof(passwordHint)-1);
				strncat(passwordHint,"' is incorrect!", sizeof(passwordHint)-1);
				
				if(giveAccess) //display main menu is user authenticated
				  welcomeMenu();
				else
				{   //invalid login credentials, display password feedback
					printf("Incorrect credentials!\n\n");
					printf(passwordHint);
					printf("\n");
				}
			}
			else 
				printf("Password cannot be empty.\n\n");
		}
		else
			printf("Username cannot be empty.\n\n");
		
	}
	
}

//login authenticator: returns 1 if valid login, 0 otherwise;
int verifyUser(char *userInput) {
	FILE *fp = fopen("credentials.txt","r"); //open file to read
	char credentials[50];
	if(fgets(credentials,50,fp)==NULL) //read file contents into buffer
	{
		printf("Error readding credentials file.\n\n");
		return 0;
	}
	fclose(fp);
	credentials[strcspn(credentials,"\r\n")] = 0; //remove trailing new line/carriage return
	if(strcmp(credentials,userInput)==0) //valid username & pw
		return 1;
	else 
		return 0;	
}

//displays main menu, reads menu commands inputted, and calls appropriate function to carry out command
void welcomeMenu() {
	//display main menu
	printf("\nWelcome Professor!\n");
	printf("----------Menu----------:\n(i)Enter 'view' to View All Student Grades\n(ii)Enter 'add1' to Add New Student\n\n");
	char command[5];
	if(fgets(command,5,stdin)) //get user menu command
	{
		//flush out excess user input from stdin (read until exhaust till hit null)
		char temp[3];
		while(!strchr(temp,'\n')) //while user input doesnt contain newline(i.e. more user input remaining, need to flush out)
			if(!fgets(temp,sizeof(temp),stdin)) //when fgets hits null in stdin (no more user input)
				break;
		
		//carry out command	
		if(strcmp(command,"view")==0)
			viewGrades();
		if(strcmp(command,"add1")==0)
			addStudent();
		if(	strcmp(command,"add1")!=0 && strcmp(command,"view")!=0 )	
			printf("Unrecognized Command.\n\n");
	}
	else
		printf("Error reading user menu input.\n\n");
}

//displays all student names and grades from file
void viewGrades() {
	FILE *fp = fopen("grades.txt","r"); //open file to read
	if(fp==NULL)
		printf("Error reading grades.txt file");
	else //file opened successfully
	{
		printf("\n");
		char c;
		c=fgetc(fp); //get first char from file
		while(c!=EOF) //loop until end of file and print every char in file 
		{
			printf("%c",c); 
			c=fgetc(fp);
		}
		printf("\n"); 
		fclose(fp);
	}
}


void addStudent() {
	char name[20];
	char grade[3];
	printf("\nEnter Student Name: ");
	scanf("%15s",name); //get name max 15 chars
	getchar(); //consume new line
	printf("Enter Letter Grade: ");
	scanf("%2s",grade); //get grade, max 2 chars
	getchar(); //consume new line
	char newEntry[20]={0}; //will contain <name,grade> combo
	strncat(newEntry,name,sizeof(newEntry)-1);
	strncat(newEntry,",",sizeof(newEntry)-strlen(name)-1);
	strncat(newEntry,grade,sizeof(newEntry)-strlen(name)-1-1);
	
	FILE *fp = fopen("grades.txt","at"); //open file to write
	if(fp==NULL)
	{
		printf("Error reading grades file.\n\n");
		return;
	}
	//file opened successfully
	fprintf(fp,"%s\r\n",newEntry); //write a new line entry to file 
	fclose(fp); 
	printf("\nNew record successfully added to file.\n\n");
}









