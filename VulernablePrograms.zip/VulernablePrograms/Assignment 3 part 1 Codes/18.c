#include <stdio.h>
#include <stdlib.h>
#include <string.h>

double balance = 500.00;

int authentication(char *pin){
    int flag = 0 ;
    char pin_buff[10];
    strcpy(pin_buff, pin);
    if(strcmp(pin_buff,"1234") == 0){
        flag = 1;
    }
    return flag;
}

void checkBalance(){
    printf("Current Balance= %lf \n\n", balance);
}

void withdraw(){
    printf("Enter the amount you want to withdraw: \n");
    int amount = 0;
    scanf("%d", &amount);
    if(amount > balance){
        printf("Insufficient Balance\n");
        exit(0);
    }else if(amount < 0){
        printf("Incorrect input\n");
        exit(0);
    }else{
        balance = balance - amount;
        printf("Transaction Successful\n");
    }
}

void deposit(){
    printf("Enter the amount you want to deposit: \n");
    int amount = 0;
    scanf("%d", &amount);
    if(amount < 0){
        printf("Incorrect input\n");
        exit(0);
    }else{
        balance = balance + amount;
        printf("Transaction Successful\n");
    }
}

void showMenu(){
    printf("What action do you want to take today:\n");
    printf(" 1. Check Balance\n");
    printf(" 2. Withdraw\n");
    printf(" 3. Deposit\n");
    printf(" 4. Exit\n");
    printf("\n\n Enter your choice: \n");
    int choice = 0;
    scanf("%d", &choice);
    if(choice == 1){
        checkBalance();
    }else if(choice == 2){
        withdraw();
    }else if(choice == 3){
        deposit();
    }else if(choice == 4){
        printf("Good Bye!!!\n");
        exit(0);
    }else{
        printf("Incorrect input. Bye!\n");
        exit(0);
    }
    showMenu();
}

void welcomeUser(){
    printf("Welcome XYZ \n\n");
    showMenu();
}

int main(int argc, char *argv[]){
    if(argc < 2){
        printf("Usuage: %s <pin>\n", argv[0]);
        exit(0);
    }
    if(authentication(argv[1])){
        welcomeUser();
    }else{
        printf("Access Denied\n");
    }
}
