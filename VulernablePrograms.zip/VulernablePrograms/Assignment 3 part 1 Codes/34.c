#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#define CMD_SIZE 521
#define NAME_SIZE 16
#define PWD_SIZE 16

void getAmount(char * name)
{
   char cmd[CMD_SIZE];
   char fileName[NAME_SIZE];

   memset(cmd, 0, CMD_SIZE);
   memset(fileName, 0, NAME_SIZE);

   strcpy(fileName, name);

   strcpy(cmd, "cat ");
   strcat(cmd, fileName);
   strcat(cmd, " | sed '1,2d'");

   system (cmd);
}

bool checkPWD(char * name, char * pwd)
{
   bool isPass = false;
   char pwdByUser[PWD_SIZE];
   char pwdInFile[PWD_SIZE];
   char fileName[NAME_SIZE];

   memset(pwdByUser, 0, PWD_SIZE);
   memset(pwdInFile, 0, PWD_SIZE);
   strcpy(fileName, name);
   strcpy(pwdByUser, pwd);

   FILE * fp = NULL;
   fp = fopen(fileName, "r");
   if ( NULL != fp )
   {
      fgets(pwdInFile, PWD_SIZE, fp);
      fgets(pwdInFile, PWD_SIZE, fp);
      fclose(fp);
      strtok(pwdInFile, "\n");
   }

   if ( 0 == strcmp(pwdByUser, pwdInFile) )
   {
      isPass = true;
   }

   return isPass;
}

int main(int argc, char * argv[])
{
   if ( argc < 2 )
   {
      printf("please give name and pwasword\n");
   }
   else
   {
      if ( checkPWD(argv[1], argv[2]) )
      {
         getAmount(argv[1]);
      }
      else
      {
         printf("wrong password!\n");
      }
   }

   return 0;
}
