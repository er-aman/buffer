#include <stdio.h> 
#include <string.h>
char* names[] = {"Jack", "Tom", "John"};
char* passwords[]={"Jack1234", "Tom1234", "John1234"};
unsigned int amount[]={500,1000,2500};
char input_string[50];
int result,i_pass,i_trans,amt,increment;
int i;
int main() 
{
here:
    printf("Enter your Login ID:- ");
    gets(input_string);
    for (i = 0; i < 3; i++)
    {
        result=strcmp(input_string,names[i]);
        if(result==0)
        {
            i_pass=i;
        }
    }
    printf("Enter your password:- ");
    gets(input_string);
    result=strcmp(input_string,passwords[i_pass]);        
    if(result==0)
    {
        printf("Password accepted\n");
        printf("You have sucessfully Logged into %s's account \n",names[i_pass]);
        printf("Your current balance is %d dollars\n",amount[i_pass]);
        printf("Enter one of these options numbers to continue \n");
        printf(" 1.Bank Statement   2.Money Transfer   3.Logout\n");
        gets(input_string);
        if(strcmp(input_string,"1")==0)
        {
            printf("Bank statement\n");            
        }
        else if(strcmp(input_string,"2")==0)
        {
            printf("Money Transfer\n");
            printf("Enter the username of the account for money transfer:-");
            gets(input_string);
            for (i = 0; i < 3; i++)
            {
                result=strcmp(input_string,names[i]);
                if(result==0)
                {
                    i_trans=i;
                }
            }
here1:            
            printf("Enter the value to be transfered:-");
            scanf("%d", &amt);
            if(amt>amount[i_pass])
            {
                printf("Insufficient Balance\n");
                goto here1;
            }
            else
            {
                amount[i_trans]+=amt;
                amount[i_pass]-=amt;
                printf("Your account balance is:-%d \n",amount[i_pass]);
                         
            }

        }
        else if(strcmp(input_string,"3")==0)
        {
            printf("Sucessfully Logged out \n");
            goto here;
        }
        
    }
    else
    {
        printf("Incorrect Login Credentials please try again\n");        
        goto here;
    }
         
	return 0; 
} 
