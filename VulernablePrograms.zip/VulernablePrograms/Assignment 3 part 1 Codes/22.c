#include<stdio.h>
#include<string.h>
int main(){
	int grading_system(char pname[20],char password[7]);
	char pname[20],password[7];
	
	printf("GRADING SYSTEM\n");
	printf("Professor Login\n");
	printf("Please enter your name\n");
	gets(pname);
	printf("Please enter the password\n");
	gets(password);
	grading_system(pname,password);
}
int grading_system(char pname[10],char password[3]){
	char sname[20],subject[10],grade[2];
	FILE *fp;
	if(strcmp(pname,"John Smith")==0 && strcmp(password,"abcde")==0){
		printf("Welcome %s\n",pname);
		
	printf("Please enter the name of the student\n");
	gets(sname);
		printf("Enter the subject\n");
	gets(subject);
	printf("Enter the grade\n");
        gets(grade);
	strcat(sname,subject);
	strcat(sname,grade);
	fp=fopen("grades.txt","a");
	fprintf(fp,sname,"\n");
	}
	else{
	printf("Invalid name or password.Please try again\n");
}return 0;
}
