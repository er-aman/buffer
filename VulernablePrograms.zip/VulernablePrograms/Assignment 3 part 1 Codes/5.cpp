#include <iostream>
using namespace std;

void getValues() {
	char from_firstName[11];
	char from_lastName[16];
	char from_creditcard[17];
	char to_firstName[11];
	char to_lastName[16];
	char to_creditcard[17];
	char memo[25];
	float amount;
	float serviceFee = 1.50; 
	cout << "Please enter your first name: ";
	cin >> from_firstName;
	cout << "Please enter your last name: ";
	cin >> from_lastName;
	cout << "Please enter your credit card number: ";
	cin >> from_creditcard;
	cout << "Please enter the recepients first name: ";
	cin >> to_firstName;
	cout << "Please enter the recepients last name: ";
	cin >> to_lastName;
	cout << "Please enter the recepients credit card number: ";
	cin >> to_creditcard;
	cout << "Please enter memo : ";
	cin >> memo;
	cout << "Please enter the amount to be sent: ";
	cin >> amount;
	cout << "Service Fee applicable for this transaction: $"<< serviceFee << endl;
	char purchaseInfo[100] = " You are about to make the following transaction: ";
	float total_amount = amount + serviceFee;
	strcat(purchaseInfo, " || ");
	strcat(purchaseInfo, from_firstName);
	strcat(purchaseInfo, " || ");
	strcat(purchaseInfo, from_lastName);
	strcat(purchaseInfo, " || ");
	strcat(purchaseInfo, to_firstName);
	strcat(purchaseInfo, " || ");
	strcat(purchaseInfo, to_lastName);
	strcat(purchaseInfo, " || ");
	strcat(purchaseInfo, memo);
	cout << "Transaction details : "<< purchaseInfo << endl;	
	cout << "--------------------------------------"<< endl;
	cout << "Thank you!" << endl;
}

int main() {
	char userName[8];
	char password[8];
	char details[4];
	cout << "Hi! Please login..." << endl;
	cout << "Enter username : " << endl;
	cin >> userName;
	cout << "Enter password : " << endl;
	cin >> password;
	if(strcmp(userName, "user123") == 0 && strcmp(password, "passkey") == 0){
		cout << "Hi! Please enter the details of the transaction!" << endl;
		getValues();
	}
	else {	
		cout << "The username and password combination is wrong!";	
	}
}	
