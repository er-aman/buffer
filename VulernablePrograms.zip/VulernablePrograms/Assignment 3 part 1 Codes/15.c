#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(void)
{
   struct{
	char uname[5];
	char password[5];
	char pass;
	}movie;
	movie.pass = 0;
	printf("\n You are at the Mega Movies \n");
	printf("\n Please login to your account with valid credentials \n");
	printf("Enter Mega Movie username: \n");
	gets(movie.uname);
	printf("Enter Mega Movie password: \n");
	gets(movie.password);
	int umatch = strcmp(movie.uname, "sanju");
   	int pmatch = strcmp(movie.password, "1993");
	if((umatch) && (pmatch))
	{
		printf("\n Your Mega Movie credentials are incorrect!\n Please enter valid Username & password \n");
	}
   	else
	{
      		printf("\n Welcome to Mega Movies!!! \n");
      		movie.pass = 1;
	}
	if(movie.pass)
	{
		printf("\n New Offers added to your account! \n");
	}
	else
	{
		printf("\n Mega Movies cannot add your account :( \n");
	}
   	return 0;
}