#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int check_auth(char *pass)
{
    char pass_buff[10];
    int flag = 0;
    strcpy (pass_buff, pass);
	
    if(strcmp(pass_buff, "Secure")==0)
        flag=1; 
	return flag;
}



void Menu(){
	int option = 0;
	printf("Choose options to see student information:\n");
	printf("\n\t	1. Personal Information");
	printf("\n\t	2. Grades");
	printf("\n\t	3. Exit");
	printf("\n Pease enter your option: ");
	scanf("%d", &option);
	StuInfo(option);
}

int StuInfo(int option){
	int showMenu = 0;
	if(option == 1){
		printf("\n Name: Harry \n ID: 1001567890 \n");
		printf("\t Email: harry.123@gmail.com \n");
		printf("\t Phone Number: +1 2234567890 \n");
        printf("\t Address: Texas,USA\n");
        printf("\n\n Name: Tom \n ID: 1001444489 \n");
		printf("\t Email: tom.123@gmail.com\n");
		printf("\t Phone Number: +1 9876543210 \n");
        printf("\t Address: Texas,USA\n");
		printf("\n To see the Main Menu please enter 1.\n");
		scanf("%d", &showMenu);
		if(showMenu == 1){
			Menu();
		} 
		
	} else if(option == 2){
		printf("\n Name: Harry \n ID: 1001567890 \n");
		printf("\t Physics: A \n");
		printf("\t Chemistry: C \n");
		printf("\t Math: A \n");
        printf("\t English: A \n");
        printf("\t Biology: A \n");
        printf("\n\n Name: Tom \n ID: 1001444489 \n");
		printf("\t Physics: B \n");
		printf("\t Chemistry: B \n");
		printf("\t Math: B \n");
        printf("\t English: B \n");
        printf("\t Biology: B \n");
		printf("\n To see the Main Menu please enter 1.\n");
		scanf("%d", &showMenu);
		if(showMenu == 1){
			Menu();
		 
		}
	}else if(option == 3){
		printf("Exiting System....\n\n");
			exit(0);
}
}

int main(int argc, char *argv[])
{
    if(argc < 2)
    {
        printf("Usage: %s <password>\n", argv[0]);
        exit(0);
    }
    if(check_auth(argv[1]))
    {
       Menu();
    }
    else
    {
        printf("Access Denied! Incorrect Password.\n");
    }

    
}

