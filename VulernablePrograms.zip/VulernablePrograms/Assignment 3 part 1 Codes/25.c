#include<stdio.h>
#include<string.h>

int auth(char *user,char *pass)
{
int flag =0;
char pass_buffer[16];
//char user_buffer[16];
strcpy(pass_buffer,pass);
//strcpy(user_buffer,user);
//if(strcmp(user_buffer,"ag")==0 & strcmp(pass_buffer,"ag")==0)
if(strcmp(pass_buffer,"sec123")==0)
flag=1;

return flag;
}

main(){
char name[16];
char password[16];
int choice,ch;
unsigned int balance = 1000,amount,phone;
printf("Welcome to online bank\n");

printf("Enter username: ");
scanf("%s",name);
printf("Enter password: ");
scanf("%s",password);
if(auth(name,password)){
printf("Welcome \n");
printf("Account number: 34235232145325\n");
printf("Bank Balance: %d\n",balance);

printf("1. Transfer money\n");
printf("Any other number to logout \n");
scanf("%d", &ch);
switch(ch){
case 1:
    printf("Enter the amount to transfer: ");
    scanf("%d",&amount);
    if(amount>balance &&amount>0){
        printf("INSUFFICENT BALANCE");
                                 }
    else{
        printf("Enter the recipient phone: ");
        scanf("%d",&phone);
        printf("Transferred successfully\n");
        balance =balance -amount;
        printf("New balance=%d \n",balance);
        }
        break;
default:
        printf("logged out\n");
        break;        
    
    }
 }
 else{
     printf("Invalid username/password\n");
 }
}
