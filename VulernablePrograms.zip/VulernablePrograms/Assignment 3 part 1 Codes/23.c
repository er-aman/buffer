#include<stdio.h>
#include<string.h>
#include<stdlib.h>

const char * flight[]={"emirates","british","etihad"};
const unsigned short price[]={2000,2048,2100};
#define n (sizeof(flight)/sizeof(const char *))

int list();
int selectflight();

int main()
{
   int i;
   int e=0;
   while(1)
   {
      printf("1.list flights\n");
      printf("2.select flight\n");
      printf("3.exit\n");
      scanf("%d",&i);
      switch(i)
      {
         case 1:list();
                break;
         case 2:e=selectflight();
                if(e==0) {printf("you are booked into emirates\n");}
                else if(e==1) {printf("you are booked into british\n");}
                else if(e==2){printf("you are booked into etihad\n");}
                else printf("you are not booked\n");
                break;
         case 3:return 0;
      }
   }
}

int list()
{
   int i;
   for(i=0;i<n;i++)
   {
      printf("%d: %s %d\n",(i+1),flight[i],price[i]);
   }
   return 0;
}

int selectflight()
{
   char name[32];
   int num;
   unsigned short finalprice;
   printf("enter flight name\n");
   scanf("%s",name);
   for(int i=0;i<n;i++)
   {
      if(strcmp(flight[i],name)==0)
      {
         printf("enter number of tickets\n");
         scanf("%u",&num);
         finalprice=num*price[i];
         printf("final price:%u\n",finalprice);
         int j;
         j=i;
         char k[32];
         printf("enter your name:\n");
         scanf("%s",k);
         return j;
      }
   }
   return 0;
}
