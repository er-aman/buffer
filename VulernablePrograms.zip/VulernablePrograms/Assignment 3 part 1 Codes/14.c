#include <stdio.h>
#include <string.h> 
void Event_Details(char name[30],char day[10],int price){
printf("\nEvent Schedule\n");
printf("%s\t",name);
printf("%s\t",day);
printf("%d\n",price);
}
int main(int argc, char *argv[])
{
int flag = 0;
char Password[10];
char name[30]="ED Sherean";
char day[10]="Sunday";
int price=5;
int count;
int selection,Choice2=1;
do{	
printf("\n*********************************");
printf("\nBook Event Tickets");
printf("\nEnter 1 for Admin Privleges\nEnter 2 To Buy tickets as Customer\n");
scanf("%d",&selection);
getchar();
if (selection==1)
{
printf("\nEnter Password:\n");
scanf("%s",&Password);
if(strcmp(Password,"root"))
{
printf("\nInvalid Password!!\n");
}
else
{
printf("\nLogged in as an Admin!!\n");
flag=1;
}
if (flag)
{
Event_Details(name,day,price);	
printf("\nEnter the updated Event name:\n");
scanf("%s",&name);
printf("\nUpdated Event details\n");
Event_Details(name,day,price);
}
}
else if(selection==2)
{
printf("Logged in as a Customer!!");
printf("Enter No of Tickets Required:");
scanf("%d",&count);
printf("Total Tickets booked: %d\n",count);
Event_Details(name,day,price);
}
else
{
printf("Invalid choice!!");
}
printf("\n===================================");
printf("\n\nenter 0 to continue 1 to exit:");
scanf("%d",&Choice2);
}while(Choice2==0);
return 0;
}

